KARTAL CONCEPT - KESİM ÖLÇÜ HESAPLAYICI PWA

DOSYALAR
- index.html : Ana uygulama
- manifest.json : Uygulama bilgileri
- service-worker.js : Çevrimdışı çalışma
- icon-180.png : iPhone ana ekran ikonu
- icon-192.png : PWA ikonu
- icon-512.png : Büyük uygulama ikonu

KURULUM
1) Bu klasördeki TÜM dosyaları aynı klasör yapısını koruyarak bir web sunucusuna yükleyin.
2) Oluşan HTTPS adresini iPhone'da Safari ile açın.
3) Paylaş butonuna dokunun.
4) "Ana Ekrana Ekle" seçeneğini seçin.
5) Ekle'ye dokunun.

NOT
PWA ve çevrimdışı çalışma için dosyaların HTTPS üzerinden yayınlanması gerekir.
